<div class="socialv-sub-product product type-product skeleton-main skeleton-list">
    <div class="socialv-inner-box ">
        <a href="#"></a>
        <div class="row">
            <div class="col-lg-4">
                <div class="skeleton skt-img">
                </div>
            </div>
            <div class="col-lg-8">
                <div class="skeleton-box">
                    <span class="skeleton skt-title mb-4"></span>
                    <span class="skeleton skt-price mb-4"></span>
                    <span class="skeleton skt-rating mb-5"></span>
                    <span class="skeleton skt-buttons mb-4"></span>
                    <span class="skeleton skt-desc"></span>
                </div>
            </div>
        </div>
    </div>
</div>