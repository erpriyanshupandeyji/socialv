<?php

use function SocialV\Utility\socialv;

 socialv()->socialv_skeleton_animation();
