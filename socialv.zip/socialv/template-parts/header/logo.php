<?php

/**
 * Template part for displaying the header logo
 *
 * @package socialv
 */

namespace SocialV\Utility;

socialv()->socialv_logo();