<?php
/**
 * Template part for displaying a pagination
 *
 * @package socialv
 */

namespace SocialV\Utility;

socialv()->socialv_pagination();
