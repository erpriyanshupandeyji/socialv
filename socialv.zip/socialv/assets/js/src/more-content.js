(function ($) {
    "use strict";
    $(document).ready(function () {
        let desc = $(document).find('.description-content');
        desc.toggleClass('showContent hideContent');
        let desc_panel_height = countLines(desc);
        desc.toggleClass('showContent hideContent');
        console.log(desc_panel_height);
        if (desc_panel_height > 3) {       
            desc.addClass('hideContent').next('.show-more').show();
            desc.next('.show-more').on('click', function () {
                let btn = $(this).find('a');
                desc.toggleClass('showContent hideContent');
                if (!desc.hasClass('showContent')) {
                    btn.text(btn.data('showmore'));
                } else {
                    btn.text(btn.data('showless'));
                }
            });
        } else {
            desc.removeClass('showContent').next('.show-more').hide();
        }
    });
}(jQuery));
var countLines = (el) => Math.round(Number(el.outerHeight() / parseInt(el.css('lineHeight').slice(0, -2))));