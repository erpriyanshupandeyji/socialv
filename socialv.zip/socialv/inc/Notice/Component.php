<?php

/**
 * SocialV\Utility\Notice\Component class
 *
 * @package socialv
 */

namespace SocialV\Utility\Notice;

use SocialV\Utility\Component_Interface;
use SocialV\Utility\Templating_Component_Interface;
use function add_action;
use function SocialV\Utility\socialv;

/**
 * Class for managing notice UI.
 *
 * Exposes template tags:
 *
 * @link https://wordpress.org/plugins/amp/
 */
class Component implements Component_Interface, Templating_Component_Interface
{
	/**
	 * Gets the unique identifier for the theme component.
	 *
	 * @return string Component slug.
	 */
	public function get_slug(): string
	{
		return 'notice';
	}

	/**
	 * Adds the action and filter hooks to integrate with WordPress.
	 */
	public function initialize()
	{
	}

	public function __construct()
	{
		if (class_exists('mediapress')) {
			add_action('admin_notices',  array($this, 'socialv_latest_mediapress_announcement'), 0);
		}
		if (class_exists('BP_Better_Messages')) {
			add_action('admin_notices',  array($this, 'socialv_latest_messages_announcement'), 0);
		}
		add_action('wp_ajax_socialv_dismiss_notice', array($this, 'socialv_dismiss_notice'), 10);
		add_action('admin_enqueue_scripts', array($this, 'socialv_notice_enqueue_admin_script'));
		add_action('wp_ajax_socialv_import_settings',  array($this, 'socialv_import_settings'));
		add_action('wp_ajax_nopriv_socialv_import_settings',  array($this, 'socialv_import_settings'));
		add_action('demo_import_media_settings', array($this, 'demo_import_media_settings'));
		add_action('demo_import_messages_settings', array($this, 'demo_import_messages_settings'));
		if (class_exists('Wpstory_Premium')) {
			add_action('after_setup_theme', array($this, 'socialv_theme_switch_support'));
		}
		// Post Update
		add_action('after_switch_theme', array($this, 'socialv_save_posts_options'));

	}

	public function template_tags(): array
	{
		return array();
	}


	public function socialv_latest_mediapress_announcement()
	{
		global $current_user;
		$user_id = $current_user->ID;
		global $wp_filesystem;
		require_once(ABSPATH . '/wp-admin/includes/file.php');
		WP_Filesystem();
		$media_setting = false;
		$import_file =  trailingslashit(get_template_directory()) . 'inc/Import/Demo/socialv-media-setting.json';
		if (file_exists($import_file)) {
			$content = $wp_filesystem->get_contents($import_file);
			if (!empty($content) && json_decode($content, true) != get_option('mpp-settings')) {
				$media_setting = true;
			}
		}
		if (!get_user_meta($user_id, 'socialv_mediapress_notification')) {
			if ($media_setting == true) { ?>
				<div class="notice notice-warning socialv-notice is-dismissible" id="socialv_mediapress_notification">
					<div class="socialv-notice-message socialv-media">
						<div class="socialv-notice-message-inner">
							<div class="socialv-heading"><?php esc_html_e('Get MediaPress plugin settings similar to SocialV Theme Demo.', 'socialv'); ?></div>
						</div>
					</div>
					<div class="socialv-notice-main-box">
						<form class="iqonic_media_form" method="post">
							<button name="socialv_media_button" class="w-100 socialv-button iqonic-data-input" type="submit" value="<?php esc_attr_e('Import MediaPress Setting', 'socialv'); ?>"><?php esc_html_e('Import MediaPress Setting', 'socialv'); ?></button>
							<input type="hidden" name="media_form_type" data-value="<?php esc_html_e('Media', 'socialv'); ?>" value="<?php esc_html_e('Media', 'socialv'); ?>" />
						</form>
						<?php
						if (isset($element_nonce) && true == $element_nonce) { ?>
							<?php wp_nonce_field('socialv_ajax_import_settings', 'socialv_ajax_import_settings_nonce'); ?>
						<?php } else { ?>
							<?php wp_nonce_field('socialv_ajax_import_settings', 'socialv_ajax_import_settings_nonce'); ?>
						<?php } ?>
					</div>
					<div class="socialv-notice-cta">
						<button class="socialv-notice-dismiss socialv-dismiss-welcome notice-dismiss" data-msg="socialv_mediapress_notification"><span class="screen-reader-text"><?php esc_html_e('Dismiss', 'socialv'); ?></span></button>
					</div>
				</div>
			<?php
			}
		}
	}


	public function socialv_latest_messages_announcement()
	{
		global $current_user;
		$user_id = $current_user->ID;
		global $wp_filesystem;
		require_once(ABSPATH . '/wp-admin/includes/file.php');
		WP_Filesystem();
		$chat_setting = false;
		$import_file =  trailingslashit(get_template_directory()) . 'inc/Import/Demo/socialv-chat-setting.json';
		if (file_exists($import_file)) {
			$content = $wp_filesystem->get_contents($import_file);
			if (!empty($content) && json_decode($content, true) != get_option('bp-better-chat-settings')) {
				$chat_setting = true;
			}
		}
		if (!get_user_meta($user_id, 'socialv_messages_notification')) {
			if ($chat_setting == true) { ?>
				<div class="notice notice-warning socialv-notice is-dismissible" id="socialv_messages_notification">
					<div class="socialv-notice-message socialv-message">
						<div class="socialv-notice-message-inner">
							<div class="socialv-heading"><?php esc_html_e('Get better messaging plugin settings similar to SocialV Theme Demo.', 'socialv'); ?></div>
						</div>
					</div>
					<div class="socialv-notice-main-box">
						<form class="iqonic_media_form" method="post">
							<button name="socialv_chat_button" class="w-100 socialv-button iqonic-data-input" type="submit" value="<?php esc_attr_e('Import Better Messages Setting', 'socialv'); ?>"><?php esc_html_e('Import Better Messages Setting', 'socialv'); ?></button>
							<input type="hidden" name="media_form_type" data-chat-value="<?php esc_html_e('Chat', 'socialv'); ?>" value='<?php esc_html_e('Chat', 'socialv'); ?>' />
						</form>
						<?php
						if (isset($element_nonce) && true == $element_nonce) { ?>
							<?php wp_nonce_field('socialv_ajax_import_settings', 'socialv_ajax_import_settings_nonce'); ?>
						<?php } else { ?>
							<?php wp_nonce_field('socialv_ajax_import_settings', 'socialv_ajax_import_settings_nonce'); ?>
						<?php } ?>
					</div>
					<div class="socialv-notice-cta">
						<button class="socialv-notice-dismiss socialv-dismiss-welcome notice-dismiss" data-msg="socialv_messages_notification"><span class="screen-reader-text"><?php esc_html_e('Dismiss', 'socialv'); ?></span></button>
					</div>
				</div>
<?php
			}
		}
	}

	public function socialv_dismiss_notice()
	{
		global $current_user;
		$user_id = $current_user->ID;
		if (!empty($_POST['action']) && $_POST['action'] == 'socialv_dismiss_notice') {
			if ($_POST['data'] === 'socialv_mediapress_notification') {
				add_user_meta($user_id, 'socialv_mediapress_notification', 'true', true);
				wp_send_json_success();
			} else if ($_POST['data'] === 'socialv_messages_notification') {
				add_user_meta($user_id, 'socialv_messages_notification', 'true', true);
				wp_send_json_success();
			}
		}
	}

	function socialv_import_settings()
	{
		// if ajax is not loaded, exit
		if (!wp_doing_ajax()) {
			exit;
		}

		if (isset($_POST['formType']) && $_POST['dataValue'] === $_POST['formType']) {
			if (isset($_REQUEST['socialv_ajax_import_settings_nonce']) && !wp_verify_nonce($_REQUEST['socialv_ajax_import_settings_nonce'], 'socialv_ajax_import_settings')) {
				exit;
			}
			do_action('demo_import_media_settings');
			echo json_encode(array('status' => 'media-success', 'message' => esc_html__('You have successfully set your MediaPress setting same as SocialV Theme Demo.', 'socialv')));
			exit();
		} elseif (isset($_POST['formType']) && $_POST['chatValue'] === $_POST['formType']) {
			if (isset($_REQUEST['socialv_ajax_import_settings_nonce']) && !wp_verify_nonce($_REQUEST['socialv_ajax_import_settings_nonce'], 'socialv_ajax_import_settings')) {
				exit;
			}
			do_action('demo_import_messages_settings');
			echo json_encode(array('status' => 'message-success', 'message' => esc_html__('You have successfully set your Better Messages setting same as SocialV Theme Demo.', 'socialv')));
			exit();
		}

		exit();
	}

	function demo_import_media_settings()
	{
		global $wp_filesystem;
		require_once(ABSPATH . '/wp-admin/includes/file.php');
		WP_Filesystem();
		$media_file =  trailingslashit(get_template_directory()) . 'inc/Import/Demo/socialv-media-setting.json';
		if (file_exists($media_file)) {
			$content = $wp_filesystem->get_contents($media_file);
			if (!empty($content)) {
				update_option('mpp-settings', json_decode($content, true));
			}
		}
	}

	function demo_import_messages_settings()
	{
		global $wp_filesystem;
		require_once(ABSPATH . '/wp-admin/includes/file.php');
		WP_Filesystem();
		$import_file =  trailingslashit(get_template_directory()) . 'inc/Import/Demo/socialv-chat-setting.json';
		if (file_exists($import_file)) {
			$content = $wp_filesystem->get_contents($import_file);
			if (!empty($content)) {
				update_option('bp-better-chat-settings', json_decode($content, true));
			}
		}
	}


	public function socialv_notice_enqueue_admin_script()
	{
		wp_enqueue_script('admin-custom', get_template_directory_uri() . '/assets/js/admin-custom.min.js', array('jquery'), socialv()->get_version());
		wp_enqueue_style('admin-custom', get_template_directory_uri() . '/assets/css/admin-custom.min.css', array(), socialv()->get_version());
	}

	function socialv_theme_switch_support()
	{
		$story_options = get_option('wp-story-premium');
		$story_options['buddypress_users_activities'] = 1;
		$story_options['buddypress_integration'] = 1;
		$story_options['buddypress_activities_form'] = 1;
		$story_options['user_publish_status'] = 'publish';
		update_option('wp-story-premium', $story_options);
	}

	function socialv_save_posts_options(){
		global $query_posts;
		$query_posts = new \WP_Query(array(
			'post_type' => array('post')
		));
		while ($query_posts->have_posts()) :
			$query_posts->the_post();
			wp_update_post(array(
				'ID' => get_the_ID(),
				'post_content' => get_the_content(),
			));
		endwhile;
		wp_reset_postdata();
	}
}
