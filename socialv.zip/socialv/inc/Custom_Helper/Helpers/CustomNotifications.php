<?php

/**
 * SocialV\Utility\Custom_Helper\Helpers\Members class
 *
 * @package socialv
 */

namespace SocialV\Utility\Custom_Helper\Helpers;

use BP_Activity_Activity;
use BP_Notifications_Notification;
use SocialV\Utility\Custom_Helper\Component;
use function SocialV\Utility\socialv;
use function add_action;

class CustomNotifications  extends Component
{

    public function __construct()
    {
        add_filter('bp_notifications_get_registered_components', [$this, 'add_custom_notification_component']);
        add_filter('bp_notifications_get_notifications_for_user', [$this, 'custom_format_buddypress_notifications'], 9, 5);
    }
    static function socialv_add_user_notification($activity_id, $args = [], $user_id = "")
    {
        $activity = new BP_Activity_Activity($activity_id);
        if ($activity) {

            $user_id = !empty($user_id) ? $user_id : get_current_user_id();
            $activity_user_id = $activity->user_id;

            $notify_user = get_user_meta($activity_user_id, "notification_activity_new_like", true);
            if ($notify_user == "no")
                return;

            if ($activity_user_id == $user_id)
                return;

            $notification_args = [
                'user_id'           => $activity_user_id,
                'item_id'           => $activity_id,
                'secondary_item_id' => $user_id,
                'component_name'    => 'socialv_activity_like_notification',
                'component_action'  => 'action_activity_liked',
                'is_new'            => 1
            ];

            $existing = BP_Notifications_Notification::get($notification_args);

            if (!empty($existing) && !$args['status']) {
                return BP_Notifications_Notification::delete(array('id' => $existing[0]->id));
            } else {
                bp_notifications_add_notification(array_merge($notification_args, ['date_notified' => bp_core_current_time()]));
            }
        }
    }

    function add_custom_notification_component($component_names = array())
    {
        // Force $component_names to be an array.
        if (!is_array($component_names)) {
            $component_names = array();
        }
        // Add 'custom' component to registered components array.
        array_push($component_names, 'socialv_activity_like_notification');
        // Return component's with 'custom' appended.
        return $component_names;
    }

    function custom_format_buddypress_notifications($action, $item_id, $secondary_item_id, $total_items, $format = 'string')
    {

        if ('action_activity_liked' === $action) {
            if (!bp_is_active('activity')) {
                return '';
            }
            $activity_link  = esc_url(bp_get_activity_directory_permalink() . "p/" . $item_id);
            $user_who_liked  = bp_core_get_user_displayname($secondary_item_id);
            if ($total_items > 1) {
                $user_who_liked .= sprintf(__('And %d more users', 'socialv'), $total_items);
            }
            $text = $user_who_liked . esc_html__(' liked your post ', 'socialv');
            $text = "<a href='$activity_link'>" . $text . "</a>";
            // WordPress Toolbar.
            if ('string' === $format) {
                $return = apply_filters('socialv_like_notification_string', '' . $text . '', $text, $activity_link);
            } else {
                return apply_filters('socialv_like_notification_array', array(
                    'text' => $text,
                    'link' => $activity_link
                ), $activity_link, (int) $total_items, $text);
            }
            return $return;
        }
    }

    function socialv_notification_avatar()
    {
        $notification = buddypress()->notifications->query_loop->notification;
        $component    = $notification->component_name;
        switch ($component) {
            case 'bp_verified_member':
                if ($notification->item_id === 0) {
                    $item_id = $notification->user_id;
                    $object  = 'user';
                }
                break;
            case 'groups':
                if (!empty($notification->item_id)) {
                    $item_id = $notification->item_id;
                    $object  = 'group';
                }
                break;
            case 'follow':
            case 'friends':
                if (!empty($notification->item_id)) {
                    $item_id = $notification->item_id;
                    $object  = 'user';
                }
                break;
            case has_action('bb_notification_avatar_' . $component):
                do_action('bb_notification_avatar_' . $component);
                break;
            default:
                if (!empty($notification->secondary_item_id)) {
                    $item_id = $notification->secondary_item_id;
                    $object  = 'user';
                } else {
                    $item_id = $notification->item_id;
                    $object  = 'user';
                }
                break;
        }
        if (isset($item_id, $object)) {
            $avatar_img = bp_core_fetch_avatar(
                array(
                    'item_id' => $item_id,
                    'object'  => $object,
                    'type'    => 'thumb',
                    'class' => 'avatar rounded-circle',
                    'width'         => 32,
                    'height'        => 32,
                )
            );
            if (!empty($avatar_img)) :
                echo '<span class="user-gap-img item-img"><div class="position-relative">' . $avatar_img;

                if ($object  === 'user') {
                    $user = new \WP_User($item_id); ?>
                    <span class="socialv-user-status <?php socialv()->socialv_is_user_online($user->ID); ?>"></span>
<?php
                }
                echo '</div></span>';
            endif;
        }
    }
}
