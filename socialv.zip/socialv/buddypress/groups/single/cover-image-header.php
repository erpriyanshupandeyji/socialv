<?php

/**
 * BuddyPress - Groups Cover Image Header.
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 * @version 3.0.0
 */

/**
 * Fires before the display of a group's header.
 *
 * @since 1.2.0
 */
do_action('bp_before_group_header'); ?>
<?php if (bp_group_use_cover_image_header()) : ?>
	<div id="cover-image-container">
		<div class="header-cover-image has_cover_image">
			<div id="header-cover-image" class="header-cover-img"></div>
		</div>
	</div><!-- #cover-image-container -->
<?php endif; ?>
<?php

/**
 * Fires after the display of a group's header.
 *
 * @since 1.2.0
 */
do_action('bp_after_group_header'); ?>