<?php

/**
 * BuddyPress - `new_avatar` activity type content part.
 *
 * This template is only used to display the `new_avatar` activity type content.
 *
 * @since 10.0.0
 * @version 10.0.0
 */

?>
<div class="bp-member-activity-preview socialv-profile-activity">

    <div class="bp-member-preview-cover">
        <a href="<?php bp_activity_generated_content_part('user_url'); ?>">
            <?php if (bp_activity_has_generated_content_part('user_cover_image')) : ?>
                <img src="<?php bp_activity_generated_content_part('user_cover_image'); ?>" alt="<?php esc_attr_e('image', 'socialv'); ?>" loading="lazy" />
            <?php else : ?>
                <img src="<?php echo esc_url(SOCIALV_DEFAULT_COVER_IMAGE); ?>" alt="<?php esc_attr_e('activity', 'socialv'); ?>" loading="lazy" />
            <?php endif; ?>
        </a>
    </div>

    <div class="bp-member-short-description">

        <?php if (bp_activity_has_generated_content_part('user_profile_photo')) : ?>
            <div class="bp-member-avatar-content has-cover-image <?php echo bp_activity_has_generated_content_part('user_cover_image') ? 'has-cover-image' : ''; ?>">
                <a href="<?php bp_activity_generated_content_part('user_url'); ?>">
                    <img src="<?php bp_activity_generated_content_part('user_profile_photo'); ?>" class=" avatar aligncenter avatar-140 rounded" alt="<?php esc_attr_e('image', 'socialv'); ?>" loading="lazy" />
                </a>
            </div>
        <?php endif; ?>
        <div class="socialv-profile-detail">
            <h5 class="bp-member-short-description-title">
                <a href="<?php bp_activity_generated_content_part('user_url'); ?>"><?php bp_activity_generated_content_part('user_display_name'); ?></a>
            </h5>

            <div class="bp-member-nickname">
                <a href="<?php is_user_logged_in() ? bp_activity_generated_content_part('user_mention_url') : bp_activity_generated_content_part('user_url'); ?>">@<?php bp_activity_generated_content_part('user_mention_name'); ?></a>
            </div>
        </div>
    </div>
</div>